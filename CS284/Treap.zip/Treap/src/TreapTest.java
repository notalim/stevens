import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

import org.junit.Test;


public class TreapTest {

    private Treap<Integer> testTree;

    @Test
    public void buildOk() {
        testTree = new Treap<Integer>();

        assertTrue(testTree.add(4 ,19));
        assertTrue(testTree.add(2 ,31));
        assertTrue(testTree.add(6 ,70));
        assertTrue(testTree.add(1 ,84));
        assertTrue(testTree.add(3 ,12));
        assertTrue(testTree.add(5 ,83));
        assertTrue(testTree.add(7 ,26));

        System.out.println(testTree);
    }

    @Test
    public void findOk() {
        testTree = new Treap<Integer>();

        testTree.add(4 ,19);
        testTree.add(2 ,31);
        testTree.add(6 ,70);
        testTree.add(1 ,84);
        testTree.add(3 ,12);
        testTree.add(5 ,83);
        testTree.add(7 ,26);

        for (int i = 1; i <= 7; i++) {
            assertTrue(testTree.find(i));
        }

        assertFalse(testTree.find(0));
        assertFalse(testTree.find(100));
    }

    @Test
    public void deleteOk() {
        testTree = new Treap<Integer>();

        testTree.add(4 ,19);
        testTree.add(2 ,31);
        testTree.add(6 ,70);
        testTree.add(1 ,84);
        testTree.add(3 ,12);
        testTree.add(5 ,83);
        testTree.add(7 ,26);

        for (int i = 1; i <= 7; i++) {
            assertTrue(testTree.delete(i));
            assertFalse(testTree.find(i));
        }

        System.out.println(testTree);
    }
}
