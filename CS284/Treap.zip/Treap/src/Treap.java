import java.util.Random;
import java.util.Stack;

public class Treap<E extends Comparable<E>> {
    private static class Node<E extends Comparable<E>> {
        public E data;
        public int priority;
        public Node <E > left;
        public Node <E > right;

        public Node (E data , int priority ) throws Exception {
            if (data == null) {
                throw new Exception("Data is null");
            }
            this.data = data;
            this.priority = priority;
            left = right = null;
        }

        Node <E> rotateRight () {
            Node <E> pivot = this.left;
            this.left = pivot.right;
            pivot.right = this;
            return pivot;
        }

        Node <E> rotateLeft () {
            Node <E> pivot = this.right;
            this.right = pivot.left;
            pivot.left = this;
            return pivot;
        }

        public String toString() {
            return "(key=" + data + ", priority=" + priority + ")";
        }
    }

    private Random priorityGenerator;
    private Node <E> root;

    public Treap () {
        priorityGenerator = new Random();
        root = null;
    }

    public Treap (long seed) {
        priorityGenerator = new Random(seed);
        root = null;
    }

    boolean add (E key) {
        int priority = priorityGenerator.nextInt();
        Node<E> node;
        try {
            node = new Node<E>(key, priority);
        } catch (Exception exc) {
            return false;
        }
        return add(node);
    }

    boolean add (E key, int priority) {
        Node<E> node;
        try {
            node = new Node<E>(key, priority);
        } catch (Exception exc) {
            return false;
        }
        return add(node);
    }

    boolean add (Node<E> node) {
        Stack<Node<E>> stack = new Stack<Node<E>>();
        Node<E> current = root;
        Node<E> previous = null;

        while (current != null) {
            previous = current;
            stack.push(previous);
            if (node.data.compareTo(current.data) < 0)
                current = current.left;
            else
                current = current.right;
        }

        if (previous == null)
            root = node;
        else if (node.data.compareTo(previous.data) < 0)
            previous.left = node;
        else
            previous.right = node;

        reheap(node, stack);

        return true;
    }

    public void reheap(Node<E> current, Stack<Node<E>> stack) {
        while (!stack.isEmpty()) {
            Node<E> parent = stack.pop();
            if (parent.priority < current.priority){
                if (parent.data.compareTo(current.data) < 0) {
                    current = parent.rotateLeft();
                } else {
                    current = parent.rotateRight();
                }
                if (!stack.isEmpty()) {
                    if (stack.peek().left == parent) {
                        stack.peek().left = current;
                    } else {
                        stack.peek().right = current;
                    }
                } else {
                    this.root = current;
                }
            } else {
                break;
            }
        }
    }

    private Node<E> delete(Node<E> node, E key){
        if (node == null) {
            return node;
        } else {
            if (node.data.compareTo(key) < 0) {
                node.right = delete(node.right, key);
            } else if (node.data.compareTo(key) > 0) {
                node.left = delete(node.left, key);
            } else {
                if (node.right == null) {
                    node = node.left;
                } else if (node.left == null) {
                    node = node.right;
                } else {
                    if (node.right.priority < node.left.priority) {
                        node = node.rotateRight();
                        node.right = delete(node.right, key);
                    } else {
                        node = node.rotateLeft();
                        node.left = delete(node.left, key);
                    }
                }
            }
        }
        return node;
    }

    public boolean delete(E key) {
        if (!find(key)) {
            return false;
        } else {
            root = delete(root, key);
            return true;
        }
    }

    private boolean find(Node<E> root, E key) {
        if (root == null) {
            return false;
        } else {
            if (root.data.compareTo(key) == 0) {
                return true;
            } else {
                return find(root.right, key) || find(root.left, key);
            }
        }
    }

    public boolean find(E key) {
        return find(root, key);
    }

    private String toString(Node<E> node, int depth) {
        StringBuilder r = new StringBuilder();
        for (int i = 0; i < depth; i++) {
            r.append("--");
        }
        if (node == null) {
            r.append("null");
        } else {
            r.append(node + "\n");
            r.append(toString(node.left, depth + 1) + "\n");
            r.append(toString(node.right, depth + 1));
        }
        return r.toString();
    }

    public String toString() {
        return toString(root, 0);
    }
}
