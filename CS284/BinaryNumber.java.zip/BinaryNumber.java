import java.lang.Math;

public class BinaryNumber {

    private int data[];
    private int length;

    public BinaryNumber(int length) {

        data = new int[length];

        this.length = length;

        for (int i = 0; i < length; i++) {
            data[i] = 0;
        }
    }

    public BinaryNumber(String str) {

        this.length = str.length();
        data = new int[length];

        for (int i = 0; i < length; i++) {
            data[i] = str.charAt(i) - '0';

        }
    }

    public String toString() {
        String str = "";
        for (int i=0; i < length; i++)
            str += data[i];
        return str;
    }

    public int getLength() {
        this.length = length;
        return length;
    }

    public int[] getInnerArray() {
        this.data = data;
        return data;
    }

    public int getDigit(int index) {
        if (index < this.length)
            return data[index];
        else throw new ArrayIndexOutOfBoundsException("index out of bounds!");
    }

    public int toDecimal() {
        int decimal = 0;
        for (int i = 0; i < length; i++) {
            decimal += data[i] * (Math.pow(2, (length - (i + 1))));
        }
        return decimal;
    }

    public void bitShift(int direction, int amount) {
        if (direction != 1 || direction != -1)
            throw new ArrayIndexOutOfBoundsException("wrong direction! it could be either 1 or -1.");
        if (direction == -1) {
            for (int i = 0; i < length - amount; i++)
                data[i] = data[i + amount];

            for (int i = amount; i < length; i++)
                data[i] = 0;
        }

        if (direction == 1) {
            for (int i = 0; i < length - amount; i++)
                data[i + amount] = data[i];

            for (int i = 0; i < amount; i++)
                data[i] = 0;
        }
    }

    public static int[] bwor(BinaryNumber bn1, BinaryNumber bn2) {
        int length1 = bn1.getLength() - 1;
        int length2 = bn2.getLength() - 1;
        if (length1 != length2) throw new ArrayIndexOutOfBoundsException("length");

        int bigger = length1 > length2 ? length1 : length2;
        int number[] = new int[bigger + 1];


        int val = 0;


        while (length1 >= 0 && length2 >= 0) {
            if (bn1.getDigit(length1) == 0 && bn2.getDigit(length2) == 0)
                val = 0;
            if (bn1.getDigit(length1) == 0 && bn2.getDigit(length2) == 1)
                val = 1;
            if (bn1.getDigit(length1) == 1 && bn2.getDigit(length2) == 0)
                val = 1;
            if (bn1.getDigit(length1) == 1 && bn2.getDigit(length2) == 1)
                val = 1;

            number[bigger] = val;

            length1--;
            length2--;
            bigger--;
        }

        return number;
    }

    public static int[] bwand(BinaryNumber bn1, BinaryNumber bn2) {
        int length1 = bn1.getLength() - 1;
        int length2 = bn2.getLength() - 1;
        if (length1 != length2) throw new ArrayIndexOutOfBoundsException("length");

        int bigger = length1 > length2 ? length1 : length2;
        int number[] = new int[bigger + 1];


        int val = 0;


        while (length1 >= 0 && length2 >= 0) {
            if (bn1.getDigit(length1) == 0 && bn2.getDigit(length2) == 0)
                val = 0;
            if (bn1.getDigit(length1) == 0 && bn2.getDigit(length2) == 1)
                val = 0;
            if (bn1.getDigit(length1) == 1 && bn2.getDigit(length2) == 0)
                val = 0;
            if (bn1.getDigit(length1) == 1 && bn2.getDigit(length2) == 1)
                val = 1;

            number[bigger] = val;

            length1--;
            length2--;
            bigger--;
        }

        return number;
    }

    public void add(BinaryNumber aBinaryNumber) {

        int val = 0;
        int sum;

        int digit1 = this.length - 1;
        int digit2 = aBinaryNumber.length - 1;

        while (digit1 >= 0 && digit2 >= 0) {
            sum = this.data[digit1] + aBinaryNumber.data[digit2] + val;

            this.data[digit1] = sum % 2;
            val = sum / 2;

            digit1--;
            digit2--;
        }

        while (digit1 >= 0) {
            sum = (this.data[digit1] + val);
            this.data[digit1] = sum % 2;
            val = sum / 2;
            digit1--;
        }






    }
}
