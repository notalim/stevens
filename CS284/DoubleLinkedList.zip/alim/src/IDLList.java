

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.StringJoiner;

public class IDLList<E> {

    //2.1.1

    public class Node<E> {

        private E data;
        private Node<E> prev = null;
        private Node<E> next = null;

        public Node(E elem) {
            data = elem;
        }

        public Node(E elem, Node<E> prev, Node<E> next) {
            data = elem;
            this.prev = prev;
            this.next = next;
        }
    }

    //2.1.2

    private Node<E> head;
    private Node<E> tail;
    private int size;
    private ArrayList<Node<E>> indices;

    public IDLList() {
        head = null;
        tail = null;
        size = 0;
        indices = new ArrayList<Node<E>>();
    }

    public boolean add(int index, E elem) {

        if (index < 0 && index > size) {
            throw new IndexOutOfBoundsException("Index out of bounds :(");
        }

        if (index == 0) {
            add(elem);
        } else if (index == size) {
            append(elem);
        } else if (index > 0 && index < size) {

            //get the node that was there before
            Node<E> old = indices.get(index);
            // make a new node to replace it
            Node<E> node = new Node<E>(elem, old.prev, old);
            //change the connections of nodes
            old.prev.next = node;
            old.prev = node;

            //now add to indices list and update the neighbors and the size of DLL
            indices.add(index, node);
            indices.set(index - 1, node.prev);
            indices.set(index + 1, node.next);
            size++;
        }
        return true;
    }

    public boolean add(E elem) {
        Node<E> node = new Node(elem, null, head);
        size++;

        // if list is empty
        if (head == null) {
            tail = node;
        } //if not
        else {
            head.prev = node;
            indices.set(0, head);
        }

        head = node;
        indices.add(0, node);

        return true;
    }

    public boolean append(E elem) {
        Node<E> node = new Node(elem, tail, null);
        size++;
        // i tried to make a case if list is empty, but i don't think it's needed because we always add in the end of the list ?
        tail.next = node;
        tail = node;
        indices.set(size, node);
        indices.add(node); // we add it in the end of the array, so no indexing needed here

        return true;
    }

    public E get(int index) {
        if (index >= 0 && index < size) {
            return indices.get(index).data;
        } else {
            throw new IndexOutOfBoundsException("Index out of bounds :(");
        }
    }

    public E getHead() {
        if (size < 0) {
            throw new IndexOutOfBoundsException("The list is empty :(");
        } else {
            return head.data;
        }
    }

    public E getLast() {
        if (size < 0) {
            throw new IndexOutOfBoundsException("The list is empty :(");
        } else {
            return tail.data;
        }
    }

    public int size() {
        return size;
    }

    public E remove() {
        //throw an exception if list is empty
        if (size == 0) {
            throw new IllegalStateException("Empty list!");
        }
        //remove the head node and change it
        E data = head.data;
        head.next = head;
        head.prev = null;
        // work with indices
        indices.remove(0);
        indices.set(0, head);

        size--;

        return data;

    }

    public E removeLast() {
        //throw an exception if list is empty
        if (size == 0) {
            throw new IllegalStateException("Empty list!");
        }
        //remove the tail node and change it
        E data = tail.data;
        tail.prev = tail;
        tail.next = null;
        size--;
        // work with indices
        indices.remove(size);


        // in case if list contains one element now
        if (tail == null) {
            head = null; }
        return data;

    }

    public E removeAt (int index) {
        //check if index is valid
        if (index > size || index < 0) {
            throw new IndexOutOfBoundsException("index out of size!");
        }
        //check if it's on either end of the list
        else if (index == 0) return remove();
        else if (index == size - 1) return removeLast();
        else {
            //initialize the node we search for
            Node<E> node = indices.get(index);
            //now remove it
            indices.remove(index);
            node.prev.next = node.next;
            node.next.prev = node.prev;
            size--;
            return node.data;
        }


    }

    public boolean remove (E elem) {
        //initialize Node with elem
        Node node = new Node(elem);
        //if it's in the head
        if (head == node) {
            remove();
        }
        else {
            //start searching for a Node with the same data (also for it's index)
            Node curr = head.next;
            int currIndex = 0;

            while (curr != null){
                if (curr.data.equals(elem)) break;
                curr = curr.next;
                currIndex++;
            }
            // if there is no such element
            if (curr == null) {
                return false;
            }
            removeAt(currIndex);
        }
        return true;
    }

    public String toString() {
        //to be honest, I copypasted this one from class, but it's obvious how it works)
        String sj = "[";
        Node<E> p = head;
        while (p.next != null) {
            sj = sj + p.toString() + ", ";
            p = p.next;
        }
        sj = sj + p.toString() + "]";
        return sj;
    }

}
