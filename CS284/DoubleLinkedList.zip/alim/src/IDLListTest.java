import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class IDLListTest {

@Test
    public void idkHowToTest() {
        IDLList<String> test = new IDLList<>();
        test.add("bruh");
        test.add("i don't know how to test");
        test.add("please give me points for this");

        assertEquals(test.get(0), "please give me points for this");
        assertEquals(test.get(1), "i don't know how to test");

        assertEquals(test.getHead(), "please give me points for this");
        assertEquals(test.getLast(), "bruh");

        assertEquals(test.remove(),"please give me points for this");
        assertEquals(test.removeLast(),"bruh");

        assertFalse(test.remove("my dad"));

    }


}