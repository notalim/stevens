package Anagrams;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class AnagramsTest {

    @Test
    public void test1() {
        Map<Character, Integer> letterTable = new HashMap<Character, Integer>();
        letterTable.put('b', 3);
        letterTable.put('c', 5);
        letterTable.put('d', 7);
        letterTable.put('e', 11);
        assertEquals(letterTable.get('b'), 3);
        assertEquals(letterTable.get('d'), 7);
        assertEquals(letterTable.get('e'), 11);
    }

    @Test
    void test2() {
        Anagrams bruh = new Anagrams();
        ArrayList<Map.Entry<Long, ArrayList<String>>> result = bruh.getMaxEntries();
        assertEquals(result.get(0).getKey(), 236204078);
    }
}
