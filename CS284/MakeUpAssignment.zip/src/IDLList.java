

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.StringJoiner;

public class IDLList<E> {

    //2.1.1

    private class Node<E> {

        private E data;
        private Node<E> prev = null;
        private Node<E> next = null;

        public Node(E elem) {
            data = elem;
        }

        public Node(E elem, Node<E> prev, Node<E> next) {
            data = elem;
            this.prev = prev;
            this.next = next;
        }
    }

    //2.1.2

    private Node<E> head;
    private Node<E> tail;
    private int size;
    private ArrayList<Node<E>> indices;

    public IDLList() {
        head = null;
        tail = null;
        size = 0;
        indices = new ArrayList<Node<E>>();
    }

    public boolean add(int index, E elem) {

        if (index < 0 && index > size) {
            throw new IndexOutOfBoundsException("Index out of bounds :(");
        }

        if (index == 0) {
            add(elem);
        } else if (index == size) {
            append(elem);
        } else if (index > 0 && index < size) {

            //get the node that was there before
            Node<E> old = indices.get(index);
            // make a new node to replace it
            Node<E> node = new Node<E>(elem, old.prev, old);
            //change the connections of nodes
            old.prev.next = node;
            old.prev = node;

            //now add to indices list and update the neighbors and the size of DLL
            indices.add(index, node);
            indices.set(index - 1, node.prev);
            indices.set(index + 1, node.next);
            size++;
        }
        return true;
    }

    public boolean add(E elem) {
        Node<E> node = new Node(elem, null, head);
        size++;

        // if list is empty
        if (head == null) {
            tail = node;
        } //if not
        else {
            head.prev = node;
            indices.set(0, head);
        }

        head = node;
        indices.add(0, node);

        return true;
    }

    public boolean append(E elem) {
        Node<E> node = new Node(elem, tail, null);
        if (node.data == null) add(elem);
        else add(size, node.data);
        return true;
    }

    public E get(int index) {
        if (index >= 0 && index < size) {
            return indices.get(index).data;
        } else {
            throw new IndexOutOfBoundsException("Index out of bounds :(");
        }
    }

    public E getHead() {
         return head.data;
    }

    public E getLast() {
            return tail.data;
    }

    public int size() {
        return size;
    }

    public E remove() {
        //throw an exception if list is empty
        if (size == 0) {
            throw new IllegalStateException("Empty list!");
        }
        //remove the head node and change it
        E data = head.data;
        if (size == 1) {
            head = null;
            tail = null;
            return data;
        }
        head.next = head;
        head.prev = null;
        // work with indices
        indices.remove(0);
        indices.set(0, head);

        size--;

        return data;

    }

    public E removeLast() {
        //throw an exception if list is empty
        if (size == 0) {
            throw new IllegalStateException("Empty list!");
        }
        //remove the tail node and change it

        E data = tail.data;
        if (size == 1) {
            head = null;
            tail = null;
            return data;
        }
        tail.prev.next = null;
        tail = tail.prev;
        size--;
        // work with indices
        indices.remove(size);

        return data;

    }

    public E removeAt (int index) {
        //check if index is valid
        if (index > size || index < 0) {
            throw new IndexOutOfBoundsException("index out of size!");
        }
        //check if it's on either end of the list
        else if (index == 0 || size == 1) return remove();
        else if (index == size - 1) return removeLast();
        else {
            //initialize the node we search for
            Node<E> node = indices.get(index);
            //now remove it
            indices.remove(index);
            node.prev.next = node.next;
            node.next.prev = node.prev;
            size--;
            return node.data;
        }


    }

    public boolean remove (E elem) {
        //initialize Node with elem
        E data = null;
        for (int i = 0; i < size; i++) {
            data = indices.get(i).data;

            if (data == elem) {
                removeAt(i);

                return true;
            }
        }
        return false;
    }

    public String toString() {
        //to be honest, I copypasted this one from class, but it's obvious how it works)
        String sj = "[";
        Node<E> p = head;
        while (p.next != null) {
            sj = sj + p.toString() + ", ";
            p = p.next;
        }
        sj = sj + p.toString() + "]";
        return sj;
    }

}

